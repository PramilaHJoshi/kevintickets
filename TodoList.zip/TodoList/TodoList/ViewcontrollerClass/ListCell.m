//
//  ListCell.m
//  TodoList
//
//  Created by Apple on 01/02/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "ListCell.h"

@implementation ListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.listView.layer.cornerRadius=4.0f;
    self.listView.clipsToBounds=YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
