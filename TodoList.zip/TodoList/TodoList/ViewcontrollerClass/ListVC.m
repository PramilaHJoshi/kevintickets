//
//  ListVC.m
//  TodoList
//
//  Created by Apple on 01/02/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import "ListVC.h"

@interface ListVC ()
{
    IBOutlet UITableView *itemListTbl;
    UITextField * namefield;
    IBOutlet UILabel *msgLbl;
    int  Index;
    NSString *nameStr;
    NSMutableArray *nameeListArr,*checkListArr,*arryResponceData;
}
@end

@implementation ListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    nameeListArr=[[NSMutableArray alloc] init];
    checkListArr=[[NSMutableArray alloc] init];
    msgLbl.hidden=YES;
    [self dbCreation];
    [self getList];
}
#pragma DB Creation
-(void)dbCreation{
    NSString *docsDir;
    NSArray *dirPaths;
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir  = dirPaths[0];
    _databasePath = [[NSString alloc]
                     initWithString: [docsDir stringByAppendingPathComponent:
                                      @"contacts.db"]];
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: _databasePath ] == NO){
        const char *dbpath = [_databasePath UTF8String];
        if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK){
            char *errMsg;
            const char *sql_stmt =
            "CREATE TABLE IF NOT EXISTS CONTACTS (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT)";
            if (sqlite3_exec(_contactDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK){
                NSLog(@"Failed to create table");
            }
            sqlite3_close(_contactDB);
        } else {
            NSLog(@"Failed to open/create database");
        }
    }
}
#pragma Save Items
-(void)SaveItemIntoList{
    sqlite3_stmt    *statement;
    const char *dbpath = [_databasePath UTF8String];
    if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK){
        NSString *insertSQL = [NSString stringWithFormat:
                               @"INSERT INTO CONTACTS (name) VALUES (\"%@\")",
                               namefield.text];
        const char *insert_stmt = [insertSQL UTF8String];
        sqlite3_prepare_v2(_contactDB, insert_stmt,
                           -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE){
            NSLog(@"Contact added");
            [self getList];
        } else {
            NSLog(@"Failed to add contact");
        }
        sqlite3_finalize(statement);
        sqlite3_close(_contactDB);
    }
}
#pragma Get Data From List
-(void)getList{
    nameeListArr=[[NSMutableArray alloc] init];
    const char *dbpath = [_databasePath UTF8String];
    sqlite3_stmt *statement;
    if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK){
        NSString *querySQL = [NSString stringWithFormat:@"SELECT * FROM CONTACTS"];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(_contactDB,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK){
            sqlite3_stmt *compiledStatement;
            if(sqlite3_prepare_v2(_contactDB, query_stmt, -1, &compiledStatement, NULL) == SQLITE_OK)
            {
                while(sqlite3_step(compiledStatement) == SQLITE_ROW){
                    [nameeListArr addObject:[NSString stringWithFormat:@"%s",(char *) sqlite3_column_text(compiledStatement,1)]];
                }
                if (nameeListArr.count>0) {
                    msgLbl.hidden=YES;
                }else{
                    msgLbl.hidden=NO;
                }
            }
            sqlite3_finalize(statement);
        }
        sqlite3_close(_contactDB);
        [itemListTbl reloadData];
    }
}
#pragma UIButton Action
- (IBAction)addItemBtnAction:(id)sender {
    
    UIAlertController * alertController = [UIAlertController
                                           alertControllerWithTitle: @"Add Your Name"
                                                            message: @""
                                                     preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Entr Your Name";
        textField.textColor = [UIColor blueColor];
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.borderStyle = UITextBorderStyleRoundedRect;
    }];
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSArray * textfields = alertController.textFields;
        namefield = textfields[0];
        NSLog(@"%@",namefield.text);
        [self SaveItemIntoList];
    }]];
    [self presentViewController:alertController animated:YES completion:nil];
}
- (IBAction)deleteListBtnAction:(id)sender {
    const char *dbpath = [_databasePath UTF8String];
    sqlite3_stmt *statement;
    if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK){
        NSString *querySQL = [NSString stringWithFormat:@"DELETE FROM CONTACTS WHERE NAME = \"%@\"",nameStr];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(_contactDB,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK){
            
            sqlite3_stmt *compiledStatement;
            if(sqlite3_prepare_v2(_contactDB, query_stmt, -1, &compiledStatement, NULL) == SQLITE_OK){
                if(sqlite3_step(statement) == SQLITE_DONE){
                    NSLog(@" Records deleted successfully..");
                }else{
                    NSLog(@" Opppsss..... Unable to delete records..");
                }
            }
            sqlite3_finalize(statement);
        }
        sqlite3_close(_contactDB);
        [self getList];
    }
}
#pragma UITableview Delegates
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60.0;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return nameeListArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    ListCell *cell =(ListCell *)[tableView dequeueReusableCellWithIdentifier:@"ListCell" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[ListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ListCell"];
    }
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.itemName.text=[nameeListArr objectAtIndex:indexPath.row];

    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [[itemListTbl cellForRowAtIndexPath:indexPath] setAccessoryType:UITableViewCellAccessoryCheckmark];
     nameStr=[nameeListArr objectAtIndex:indexPath.row];
}
-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [[itemListTbl cellForRowAtIndexPath:indexPath] setAccessoryType:UITableViewCellAccessoryNone];
    nameStr=@"";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
