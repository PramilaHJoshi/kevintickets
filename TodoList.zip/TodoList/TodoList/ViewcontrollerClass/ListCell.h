//
//  ListCell.h
//  TodoList
//
//  Created by Apple on 01/02/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIView *listView;


@property (strong, nonatomic) IBOutlet UILabel *itemName;

@end
