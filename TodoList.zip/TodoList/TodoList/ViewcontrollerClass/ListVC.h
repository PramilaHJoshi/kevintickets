//
//  ListVC.h
//  TodoList
//
//  Created by Apple on 01/02/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListCell.h"
#import <sqlite3.h>

@interface ListVC : UIViewController


@property (strong, nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *contactDB;
@end
